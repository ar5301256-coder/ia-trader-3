# IA TRADER 3 — protótipo Android v0.1.0

Este projeto gera um APK Android de depuração por GitHub Actions. O app abre um simulador local offline.

## O que funciona nesta versão
- Painel com patrimônio virtual inicial de R$ 100 (R$ 50 BTC / R$ 50 B3).
- Preços sintéticos aleatórios, apenas para exercitar o simulador.
- Compra e venda manuais virtuais.
- Alternância de operação automática simulada.
- Limite de perda de 5% sobre o capital inicial, que pausa a automação.
- Histórico local e persistência no aparelho.
- Regra adaptativa experimental que altera o limiar após pelo menos três fechamentos.

## Limitações importantes
- Não usa cotações reais, não acessa corretoras e não envia ordens.
- O ativo B3 é um índice ilustrativo, não uma ação negociável.
- O módulo adaptativo é uma regra demonstrativa, não aprendizado de máquina treinado.
- APK debug não é uma versão assinada para distribuição pública.

## Gerar APK pelo celular usando GitHub
1. Crie um repositório vazio chamado `ia-trader-3` no GitHub.
2. No navegador do Android, abra o repositório e use **Add file > Upload files**.
3. Envie o conteúdo desta pasta (arquivos e pastas, incluindo `.github`). Se o GitHub móvel não permitir enviar pastas ocultas, use o GitHub Desktop não será necessário: habilite a visualização de arquivos ocultos no gerenciador ou faça upload pelo navegador em modo computador.
4. Faça commit na branch `main`.
5. Abra a aba **Actions**, selecione **Build IA TRADER APK** e aguarde ficar verde.
6. Abra a execução concluída e baixe o artefato `IA-TRADER-3-debug-apk`.
7. Extraia o ZIP e instale `app-debug.apk`. O Android poderá pedir autorização para instalar apps dessa fonte.

## Desenvolvimento
Projeto Android nativo mínimo: Kotlin + WebView local, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK 35, minSdk 24.
