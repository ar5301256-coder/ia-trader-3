plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iatech.iatrader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.iatech.iatrader"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
